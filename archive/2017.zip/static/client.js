import React from 'react'
import ReactDOM from 'react-dom'
import { Route, Router, IndexRoute, browserHistory } from 'react-router'
import Index from '../components/containers/Index.js'
import DataVis from '../components/containers/DataVis.js'

class Layout extends React.Component {
  render() {
    return (<div>{this.props.children}</div>)
  }
}

const routes = (
  <Route path='/' component={Layout}>
    <IndexRoute component={Index}/>
    <Route path='/dv' component={DataVis}/>
    <Route path='*' component={Index}/>
  </Route>
)

ReactDOM.render(
  <Router history={browserHistory} routes={routes} onUpdate={() => window.scrollTo(0, 0)}/>,
  document.getElementById('app')
)