const webpack = require('webpack')
const combineLoaders    = require('webpack-combine-loaders')
const ExtractTextPlugin = require('extract-text-webpack-plugin')

module.exports = {
  entry: __dirname+'/../static/client.js',
  output: {
    path: __dirname+'/../static',
    filename: 'js/client.min.js'
  },
  module: {
    loaders: [
      {
        test: /\.css$/,
        loader: ExtractTextPlugin.extract(
          combineLoaders([{
            loader: 'css-loader',
            query: {
              modules: true,
              localIdentName: '[name]__[local]___[hash:base64:5]'
            }
          }])
        )
      },
      {
        test: /\.jsx?$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        query: {
          presets: ['react', 'es2015']
        }
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin('css/styles.css'),
    new webpack.DefinePlugin({
      'process.env': { 
         NODE_ENV: JSON.stringify('production')
       }
    }),
    new webpack.optimize.DedupePlugin(),
    new webpack.optimize.OccurenceOrderPlugin(),
    new webpack.optimize.UglifyJsPlugin({ compress: { warnings: false }})
  ]
}