export default (() => {
  let self = {}

  self.CDN_URL = 'https://dysrf6t0c7f2p.cloudfront.net/'

  self.DATAVIS = {
    MAX_DATA: 50,
    INTERVAL: 1*1000
  }

  return self
})()
