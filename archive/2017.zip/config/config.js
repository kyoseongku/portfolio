require('dotenv').config()

module.exports = (() => {
  let self = {}

  self.PORT = process.env.NODE_ENV === 'production' ? 80 : 3210

  self.STATIC_PATH = __dirname+'/../static/'

  self.MONGO = {
    URL: process.env.MONGO_URL,
    DB: process.env.MONGO_DB,
    COLLECTIONS: {
      TIMECARD: process.env.MONGO_TIMECARD
    }
  }

  return self
})()
