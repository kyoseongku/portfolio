# Henlo world

Restarted repo and portfolio because v2 had ugly branching and commit messages, API keys for side projects and whatnot expired, and code wasn't the prettiest

## Versioning
* **3.0.0**
	* Data visualization
		* Basic line and radial charts
		* Smooth animation - *on hold*
	* Migrate stuff over from v2 - *in progress*
	* Hosted on AWS [here](http://www.kyoseong.com)
* **2.0.0**
	* Was basically my first experimentation with React
	* Had some cool side project demos on there
		* Simple augmented reality with color tracking [demo video](https://dysrf6t0c7f2p.cloudfront.net/ar.mp4)
		* P2P video chat using WebRTC and WebGL (three.js)
			* Peer's video was on the center of the screen on the surfaces of a rotating cube
			* User's video was on a sphere that orbited around the cube
	* Hosted on AWS
	* It was alright, can be found in [archive/2016.zip](archive)
* **1.0.0**
	* Built with vanilla HTML, CSS, JS
	* Hosted on Firebase before they were bought by Google
	* It was pretty terrible

## TODO
Type | Description | Requested by | Requested on | Status
--- |--- | --- | --- | ---
Requirement | Migrate stuff over from v2 | Austin | 12/30/17 | in progress
Experiment | Data visualization | Austin | 12/30/17 | on hold