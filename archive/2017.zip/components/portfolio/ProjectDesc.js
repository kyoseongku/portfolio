import React from 'react'
import styles from './ProjectDesc.css'
import sch from '../../data/projects.text.js'
import dylect from '../../data/dylect.text.js'

export default class ProjectDesc extends React.Component {
  render() {
    let key = this.props.project
    let text = key === 'dylect' ? dylect : sch

    return (
      <div className={styles.wrapper}>
        <div className={styles.title}>
          <p><b>{text[key].title}</b> {text[key].info}</p>
        </div>
        {
          text[key].role && text[key].role !== '' && (
            <div className={styles.role}>
              <p><b>Responsibility: </b>{text[key].role}</p>
            </div>
          )
        }
        {
          text[key].points.length > 0 && (
            <p><b>Features implemented:</b></p>
          )
        }
        {
          text[key].points.map((point, index) => {
            return (
              <div key={index} className={styles.point}>
                <i className='material-icons cyan-text'>check</i>
                <span>{point}</span>
              </div>
            )
          })
        }
      </div>
    )
  }
}
