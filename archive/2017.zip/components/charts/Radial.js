import React from 'react'
import styles from './Radial.css'

export default class Radial extends React.Component {
  componentDidUpdate() {
    d3.selectAll(`#${this.props.id} > *`).remove()

    let lastTemp = this.props.data.values[this.props.data.values.length-1].temperature
    let max = 150
    let thickness = 10

    let svg = d3.select('#'+this.props.id)
      .append('g')
      .attr('transform', `translate(${this.props.width/2},${this.props.height/2})`)

    let arc = d3.arc()
      .startAngle(0)
      .innerRadius((this.props.width/2)-thickness)
      .outerRadius((this.props.width/2))

    let meter = svg.append('g')
      .attr('class', styles['progress-meter'])
    meter.append('path')
      .attr('class', styles.background)
      .attr('d', arc.endAngle(2*Math.PI))

    let foreground = meter.append('path')
      .attr('class', styles.foreground)
      .attr('d', arc.endAngle(2*Math.PI*(lastTemp/max)))

    meter.append('text')
      .attr('text-anchor', 'middle')
      .attr('y', -9)
      .attr('dy', '.20em')
      .attr('fill', '#fff')
      .text(this.props.data.name)
    meter.append('text')
      .attr('text-anchor', 'middle')
      .attr('y', 9)
      .attr('dy', '.20em')
      .attr('fill', '#fff')
      .text(lastTemp+'F')
  }

  render() {
    return <svg id={this.props.id} height={this.props.height} width={this.props.width}></svg>
  }
}
