import React from 'react'
import styles from './Line.css'

export default class Line extends React.Component {
  componentDidUpdate() {
    d3.selectAll(`#${this.props.id} > *`).remove()

    let svg = d3.select('#'+this.props.id)
    let margin = {
      top: 20,
      right: 80,
      bottom: 30,
      left: 50
    }
    let width = svg.attr('width')-margin.left-margin.right
    let height = svg.attr('height')-margin.top-margin.bottom

    let g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`)
    let x = d3.scaleTime().range([0, width])
    let y = d3.scaleLinear().range([height, 0])
    let z = d3.scaleOrdinal(d3.schemeCategory10)

    let line = d3.line().curve(d3.curveBasis)
      .x(val => { return x(val.time) })
      .y(val => { return y(val.temperature) })

    x.domain(d3.extent(this.props.data[0].values, val => val.time))

    y.domain([
      d3.min(this.props.data, server => {
        return d3.min(server.values, val => val.temperature)
      }),
      d3.max(this.props.data, server => {
        return d3.max(server.values, val => val.temperature)
      })
    ])

    z.domain(this.props.data.map(server => server.name))

    g.append('g')
      .attr('class', `axis ${styles['axis--x']}`)
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .append('text')
        .attr('x', this.props.width-160)
        .attr('y', -10)
        .attr('dy', '0.71em')
        .attr('fill', '#fff')
        .text('Time, seconds')

    g.append('g')
        .attr('class', `axis ${styles['axis--y']}`)
        .call(d3.axisLeft(y))
      .append('text')
        .attr('transform', 'rotate(-90)')
        .attr('y', 6)
        .attr('dy', '0.71em')
        .attr('fill', '#fff')
        .text('Temperature, F')

    let server = g.selectAll('.server')
      .data(this.props.data)
      .enter().append('g')
        .attr('class', 'server')

    server.append('path')
      .attr('class', styles.line)
      .attr('d', d => { return line(d.values) })
      .style('stroke', d => { return z(d.name) })

    server.append('text')
      .datum(d => {
        return {
          name: d.name,
          value: d.values[d.values.length-1]
        }
      })
      .attr('transform', d => `translate(${x(d.value.time)},${y(d.value.temperature)})`)
      .attr('x', 3)
      .attr('dy', '0.35em')
      .style('font', '10px sans-serif')
      .attr('fill', '#fff')
      .text(d => d.name)
  }

  render() {
    return <svg id={this.props.id} height={this.props.height} width={this.props.width}></svg>
  }
}
