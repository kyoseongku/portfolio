import React from 'react'
import axios from 'axios'
import styles from './Index.css'
import ProjectDesc from '../portfolio/ProjectDesc'
import CONFIG from '../../config/config.ui.js'



export default class Index extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      sch: 'none',
      animationOffset: 0.25*$(window).height() // Animation start height for each section icon
    }

    this.data = {
      miniProjects: [
        { name: 'dv', src: CONFIG.CDN_URL+'heli.jpg' },
        { name: 'ar', src: CONFIG.CDN_URL+'ar.png' },
        { name: 'vc', src: CONFIG.CDN_URL+'vchat.jpg' },
        { name: 'tc', src: CONFIG.CDN_URL+'chat2.jpg' },
        { name: 'map', src: CONFIG.CDN_URL+'map.jpg' },
        { name: 'heli', src: CONFIG.CDN_URL+'heli.jpg' },
        { name: 'sched', src: CONFIG.CDN_URL+'sched.jpg' }
      ]
    }

    this.handleResize = this.handleResize.bind(this)
    this.goToProj = this.goToProj.bind(this)
    this.goToResume = this.goToResume.bind(this)
  }



  componentDidMount() {
    $(window).on('resize', this.handleResize)
    this.handleResize()

    setTimeout(() => {
      $(`.${styles.sectionGreeting} h2`).addClass('animated wobble');
    }, 250)

    Materialize.scrollFire([
      {
        selector: `.${styles.sectionWork} .${styles.sectionHeader} i`,
        offset: this.state.animationOffset,
        callback: () => {
          $(`.${styles.sectionWork} .${styles.sectionHeader} i`).addClass('animated swing')
        }
      },
      {
        selector: `.${styles.sectionProjects} .${styles.sectionHeader} i`,
        offset: this.state.animationOffset,
        callback: () => {
          $(`.${styles.sectionProjects} .${styles.sectionHeader} i`).addClass('animated hinge')
        }
      },
      {
        selector: `.${styles.sectionMe} .${styles.sectionHeader} i`,
        offset: this.state.animationOffset,
        callback: () => {
          $(`.${styles.sectionMe} .${styles.sectionHeader} i`).addClass('animated flip')
        }
      },
      {
        selector: `.${styles.sectionSkills}`,
        offset: this.state.animationOffset,
        callback: () => {
          let helper = (elem, amt) => {
            if(amt >= 1)
              return
            $(elem).css('width', `${Number($(elem).data('max'))*amt}%`)
            setTimeout(helper, 50, elem, amt+0.05)
          }

          $.each($('.determinate'), (index, elem) => {
            setTimeout(helper, 250, elem, 0)
          })
        }
      }
    ])

    window._god = (key) => {
      axios.post('/god', { key }).then(response => {
        console.log(response.data)
      }).catch(error => {
        console.log(error.response.data)
      })
    }
  }



  componentWillUnmount() {
    $(window).off('resize')
    delete window._god
  }



  handleResize() {
    let self = this

    $(`.${styles.sectionDark}, .${styles.sectionLight}`).css({
      'min-height': $(window).height()
    })

    $(`.${styles.sectionGreeting}`).css({
      'padding-top': ($(window).height()-$(`.${styles.sectionGreeting}`).outerHeight())/2
    })

    $(`.${styles.meImg}`).css({
      height: 0.75*$(window).height()
    })

    $(`.${styles.meImgBtn}`).css({
      top: $(`.${styles.meImg}`).outerHeight()-$(`.${styles.meImgBtn}`).outerHeight()+'px'
    })

    this.setState({
      animationOffset: 0.25*$(window).height()
    })
  }



  goToProj(proj) {
    console.log(proj)
  }



  goToResume() {
    window.location.href = CONFIG.CDN_URL+'resume-kyoseong_ku.pdf'
  }



  render() {
    return (
      <div>
        <div className={styles.sectionDark}>
          <div className='container'>
            <div className={styles.sectionGreeting}>
              <h2 className='light'>hello</h2>
              <h4 className='light'>My name is Kyoseong (Austin), and I like to build things</h4>
              <p>update in progress</p>
            </div>
          </div>
        </div>
        <div className={styles.sectionLight}>
          <div className='container'>
            <div className={styles.sectionWork}>
              <div className={styles.sectionHeader}>
                <i className='material-icons medium brown-text text-lighten-1'>card_travel</i>
                <h4 className='light'>work experience</h4>
              </div>
              <div className='row'>
                <div className='col s12 m3'>
                  <div className={styles.schLogo}>
                    <img src={CONFIG.CDN_URL+'logo_sch.png'}/>
                    <p>Feb. 2017 - Present</p>
                    <p>Software Developer</p>
                  </div>
                  <div>
                    <div className={styles.schBtnsDark}>
                      <a onClick={()=>{this.setState({ sch: 'pl'  })}}>Paperless</a>
                      <a onClick={()=>{this.setState({ sch: 'ns'  })}}>Notifications</a>
                      <a onClick={()=>{this.setState({ sch: 'sm'  })}}>SuperMon</a>
                      <a onClick={()=>{this.setState({ sch: 'dfa' })}}>DocFlow Assist</a>
                      <a onClick={()=>{this.setState({ sch: 'se'  })}}>SuperEye</a>
                      <a onClick={()=>{this.setState({ sch: 'ib'  })}}>iBreathe API</a>
                      <a onClick={()=>{this.setState({ sch: 'dtb' })}}>DeliveryTrack Board</a>
                      <a onClick={()=>{this.setState({ sch: 'im'  })}}>Inventory Management</a>
                    </div>
                    <div className={styles.schBtnsLight}>
                      <a onClick={()=>{this.setState({ sch: 'df' })}}>DocFlow</a>
                      <a onClick={()=>{this.setState({ sch: 'dt' })}}>DeliveryTrack</a>
                    </div>
                  </div>
                </div>
                <div className='col s12 m9'>
                  <ProjectDesc project={this.state.sch}/>
                </div>
              </div>
              <div className={styles.sectionWorkSub}>
                <div className={styles.sectionHeader}>
                  <h5 className='light'>General development</h5>
                </div>
                <div className='row'>
                  <div className='col s12 m6 l6'>
                    <p><b>Documentation</b></p>
                    <p>Ensured maintainability by providing notes, included features in each version, notes on development such as how to setup the environment, and documentation on each API endpoint including sample request and responses.</p>
                  </div>
                  <div className='col s12 m6 l6'>
                    <p><b>Testing</b></p>
                    <p>Ensured predictable execution and caught errors early by writing test scripts</p>
                    <p>Also authored interactive CLI manual test scripts to simulate human interactions</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.sectionDark}>
          <div className='container'>
            <div className={styles.sectionProjects}>
              <div className={styles.sectionHeader}>
                <i className='material-icons medium blue-grey-text'>build</i>
                <h4 className='light'>projects</h4>
              </div>
              <div className='row'>
                <div className='col s12 m3'>
                  <div className={styles.dylectLogo}>
                    <img src={CONFIG.CDN_URL+'dylect.png'}/>
                    <p>Dylect</p>
                    <p>Co-founder</p>
                  </div>
                </div>
                <div className='col s12 m9'>
                  <ProjectDesc project={'dylect'}/>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.sectionProjectsSub}>
            <div className={styles.sectionHeader}>
              <h4 className='light'>other minor fiddles</h4>
              <p>(Click each image for more details)</p>
            </div>
            <div className='row'>
              {
                this.data.miniProjects.map((proj, index) => {
                  return (
                    <div key={index} className={`col s12 m6 l4 ${styles.miniProj}`} onClick={() => { this.goToProj(proj.name) }}>
                      <img src={proj.src} className='responsive-img'/>
                    </div>
                  )
                })
              }
            </div>
          </div>
        </div>
        <div className={styles.sectionLight}>
          <div className='container'>
            <div className={styles.sectionMe}>
              <div className={styles.sectionHeader}>
                <i className='material-icons medium amber-text'>perm_identity</i>
                <h4 className='light'>me</h4>
              </div>
              <div className='row'>
                <div className='col s12 m6 l6'>
                  <div className={styles.schoolLogo}>
                    <img src={CONFIG.CDN_URL+'ucla_logo.png'}/>
                    <h4 className='light'>Computer Science, B.S.</h4>
                    <p><b>University of California, Los Angeles</b></p>
                    <p>Graduated Dec. 2015</p>
                  </div>
                </div>
                <div className='col s12 m6 l6'>
                  <div className={styles.schoolClasses}>
                    <h4 className='light'>Relevant coursework</h4>
                    <p>Algorithms &amp; Complexity</p>
                    <p>Artificial Intelligence</p>
                    <p>Computer Graphics</p>
                    <p>Database Systems</p>
                    <p>Data Structures</p>
                    <p>Formal Languages &amp; Automata Theory</p>
                    <p>Machine Architecture</p>
                    <p>Network Fundamentals</p>
                    <p>Object-oriented Programming</p>
                    <p>Operating Systems</p>
                    <p>Programming Languages</p>
                    <p>Software Engineering</p>
                    <p>Web Applications</p>
                    <p>---</p>
                    <p>Entrepreneurship for Engineers</p>
                    <p>Finance and Marketing for Engineers</p>
                    <p>Systems Engineering</p>
                  </div>
                </div>
              </div>
              <hr/>
              <div className={styles.sectionSkills}>
                <div className={styles.sectionHeader}>
                  <h4 className='light center'>Skills</h4>
                </div>
                <div className='row'>
                  <div className='col s12 m6 offset-m3 l6 offset-l3'>
                    <div className='progress white'><div className='determinate blue' data-max='75'></div></div>
                    <p><b>Heavy usage:</b></p>
                    <p>HTML | CSS | JavaScript/Node.js (ES6)</p>
                    <p>Amazon Web Services | Express | git | Jade/Pug | jQuery | Linux | Materialize | NoSQL | React | Regular expressions </p>
                    <br/>
                    <div className='progress white'><div className='determinate blue' data-max='50'></div></div>
                    <p><b>Light usage:</b></p>
                    <p>C | C++ | Java</p>
                    <p>Bootstrap | d3.js | Google (APIs and Cloud Platform) | Shell script | Socket.io | WebRTC | WebGL (three.js)</p>
                    <br/>
                    <div className='progress white'><div className='determinate blue' data-max='25'></div></div>
                    <p><b>Exposed to:</b></p>
                    <p>Assembly | Lisp | MySQL | OCaml | PHP | Python</p>
                    <br/>
                    <div className={styles.ghBtn}>
                      <a href='https://github.com/kyoseongku' target='_blank' className={`btn-large blue ${styles.repo}`}>GitHub</a>
                    </div>
                  </div>
                </div>
                <hr/>
                <div className='row'>
                  <div className='col s12 m6 offset-m3 l6 offset-l3'>
                    <div className={styles.meImg}>
                      <img src={CONFIG.CDN_URL+'me.jpg'}/>
                      <div className={styles.meImgBtn} onClick={this.goToResume}>
                        <h5 className='light'>Click for a PDF version of my resume</h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
