import React from 'react'
import styles from './DataVis.css'
import * as actions from '../../actions/dataVis.js'
import CONFIG from '../../config/config.ui.js'
import Line from '../charts/Line'
import Radial from '../charts/Radial'

export default class DataVis extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      data: [],
      servers: []
    }

    this.handleResize = this.handleResize.bind(this)
    this.update = this.update.bind(this)
  }

  componentDidMount() {
    $(window).on('resize', this.handleResize)
    this.handleResize()
    this.update()
  }

  componentWillUnmount() {
    $(window).off('resize')
    if(this._timer)
      clearTimeout(this._timer)
  }

  handleResize() {
    $(`.${styles.wrapper}`).css({
      'min-height': $(window).height()
    })
  }

  update() {
    actions.getData().then(data => {
      let newState = {
        data: this.state.data.slice(0),
        servers: this.state.servers.slice(0)
      }

      data.forEach(serverData => {
        if(newState.servers.indexOf(serverData.name) < 0) {
          newState.servers.push(serverData.name)
          newState.data.push({
            name: serverData.name,
            values: [serverData]
          })
        }
        else {
          for(let i = 0; i < newState.data.length; i++) {
            if(newState.data[i].name === serverData.name) {
              newState.data[i].values.push(serverData)
              if(newState.data[i].values.length > CONFIG.DATAVIS.MAX_DATA)
                newState.data[i].values.shift()
              break
            }
          }
        }
      })

      this.setState({
        data: newState.data,
        servers: newState.servers
      }, () => {
        this._timer = setTimeout(this.update, CONFIG.DATAVIS.INTERVAL)
      })
    }).catch(error => {
      console.log(error)
    })
  }

  render() {
    return (
      <div className={styles.wrapper}>
        <div className='container'>
          <div className='blue-grey-text text-lighten-5'>
            <h4 className='light'>Data visualization fiddle using random data</h4>
            <p>TODO: smooth animation</p>
          </div>
          {
            this.state.data.length > 0 && (
              <div>
                <Line id='line' height={500} width={800} data={this.state.data}/>
                {
                  this.state.data.map((serverData, i) => {
                    return <Radial key={i} id={'radial_'+i} height={150} width={150} data={serverData}/>
                  })
                }
              </div>
            )
          }
        </div>
      </div>
    )
  }
}
