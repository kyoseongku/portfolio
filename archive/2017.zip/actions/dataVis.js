import Promise from 'bluebird'

export function getData() {
  const MIN_VAL = 50
  const MAX_VAL = 100

  let time = Date.now()
  let _rand = () => Math.floor(Math.random()*(MAX_VAL-MIN_VAL)+MIN_VAL)

  return Promise.resolve([
    {
      time,
      temperature: _rand(),
      name: 'Server Uno'
    },
    {
      time,
      temperature: _rand(),
      name: 'Server Dos'
    },
    {
      time,
      temperature: _rand(),
      name: 'Server Tres'
    }
  ])
}