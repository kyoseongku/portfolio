const http    = require('http')
const express = require('express')
const mongo   = require('mongodb').MongoClient
const bParser = require('body-parser')
const path    = require('path')
const Promise = require('bluebird')
const CONFIG  = require('./config/config.js')

const app    = express()
const server = http.createServer(app)
const io     = require('socket.io')(server)
const mongoConnect = Promise.promisify(mongo.connect)

app.use(express.static(CONFIG.STATIC_PATH))
app.use(bParser.json())
app.use(bParser.urlencoded({ extended: false }))

// It's a small personal project, so whatevers
global.db = {}
global.god = {}



// React catch-all
app.get('*', (req, res, next) => {
  let ignorables = [ 'fonts' ]
  if(req.originalUrl.split('/').length > 1 && ignorables.indexOf(req.originalUrl.split('/')[1]) < 0)
    console.log(`${new Date().toString()}: ${req.originalUrl}`, { ua: req.headers['user-agent'] })

  res.sendFile(path.resolve(CONFIG.STATIC_PATH+'index.html'))
})



app.post('/god', (req, res, next) => {
  if(req.body.key && req.body.key === process.env.GOD_KEY) {
    return res.send({
      message: 'Henlo god',
      token: process.env.GOD_TOKEN
    })
  }

  res.send({ message: 'You are not god' })
})



mongoConnect(CONFIG.MONGO.URL).then(client => {
  let db = client.db(CONFIG.MONGO.DB)
  global.db.timecard = db.collection(CONFIG.MONGO.COLLECTIONS.TIMECARD)
  console.log('Connected to Mongo')

  server.listen(CONFIG.PORT, () => {
    console.log(`Server up in ${process.env.NODE_ENV} mode @ port ${CONFIG.PORT}`)
  })
}).catch(console.log)
