export default {
  dylect: {
    title: 'Dylect',
    info: 'was my educational technology startup effort. Dylect (dynamic + lectures) allows educators to expand their services beyond brick walls through video chat built into the browser alongside scheduling functionality and more.',
    role: '',
    points: [
      'Developed a peer-to-peer, one-on-one video chat web app, which reduced server costs since the media data is transferred directly between the two participants',
      'Built and integrated into the video chat a collaborative whiteboard with the ability to share images onto the whiteboard and draw on them',
      'Integrated a text chat system with translation and speech recognition features',
      'Implemented cron jobs using AWS Lambda, since multiple server instances can lead to multiple cron job executions',
      'Cookie-based session management',
      "Detected if the visitor's cookies or JavaScript were disabled and displayed a notification with instructions on how to enable them",
      'Automated notification emails',
      'CRUD on user accounts'
    ],
    tags: [
      'Front-end',
      'Back-end',
      'Node.js',
      'Express',
      'WebSockets',
      'WebRTC',
      'AWS (EC2)',
      'AWS (DynamoDB)',
      'AWS (S3)',
      'AWS (Lambda)',
      'Google API (Gmail)',
      'Pug/Jade',
      'Material design'
    ]
  }
}