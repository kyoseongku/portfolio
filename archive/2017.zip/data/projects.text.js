export default {
  none: {
    title: '',
    info: 'Click on a project to view details',
    role: '',
    points: [],
    tags: []
  },
  pl: {
    title: 'Paperless',
    info: 'is a digital signatures application, along with tools to create signable documents',
    role: 'Developed the API server and its auxiliary back-end processes',
    points: [
      'Interactive CLI scripts to render PNGs of documents templated with Pug',
      'Generate PNGs of documents with embedded dynamic data and custom QR codes',
      'Ability to split data and render multi-page documents when provided with a lengthy collection of data',
      'Merge multiple PNG images into a single PDF and email it as an attachment via the Notification Service project',
      'In addition to signatures, front-end is able to fill-in checkboxes, radios, and text fields',
      'Reduced load and provided horizontal scalability by offloading image processing to AWS Lambda functions',
      'Implemented the image upload and download endpoints on AWS Lambda for parallelizable transfers to and from the encrypted S3',
      'Mitigated connection timeouts and spikes in server load by using periodic tasks to process queued packages in parallel in batches',
      'Error accumulator for high-frequency tasks to send a condensed request to the Notification Service',
      'JWT-based authentication middleware',
      'Test suite composed of automated and manual test scripts',
      'Versioned API endpoints and documents'
    ],
    tags: [
      'Back-end',
      'Node.js',
      'AWS (EC2)',
      'AWS (S3)',
      'AWS (DynamoDB)',
      'AWS (API Gateway)',
      'AWS (Lambda)',
      'MongoDB',
      'Pug/Jade',
      'PhantomJS',
      'Mocha & Chai'
    ]
  },
  ns: {
    title: 'Notification Service',
    info: 'sends email alerts to the IT department in case of errors and to the sales department regarding new orders',
    role: 'Developed the API server',
    points: [
      'Redesigned on a serverless architecture',
      'Receives information about errors from internal applications, then a periodic task aggregates them by application and sends a compact email',
      'Sends error notification emails with the ability to respond/interact through a button',
      'Receives information about new orders/faxes and notifies the appropriate sales representative',
      'Ability to send mass emails based on user groups',
      'Ability to send HTML emails and with attachments'
    ],
    tags: [
      'Back-end',
      'Node.js',
      'Go',
      'AWS (EC2, Lambda, DynamoDB, API Gateway)',
      'MongoDB',
      'Google API (Gmail)',
      'SendGrid'
    ]
  },
  sm: {
    title: 'SuperMon',
    info: 'is a collection of back-end processes that monitor servers and the web applications running on them',
    role: 'Developed the full-stack web application, and rewrote the back-end using Go',
    points: [
      'Runs on 14 servers monitoring 51 processes (13 physical/EC2 Ubuntu machines and 1 Windows server)',
      'Detects crashed processes as well as "frozen" processes, which were previously difficult to detect',
      "Monitors servers' RAM and heap usage of memory-intensive processes",
      'Alerts the IT department of crashes, freezes, low memory, etc. via the Notification Service',
      'Web dashboard to view live status of monitored servers and processes'
    ],
    tags: [
      'Front-end',
      'Back-end',
      'Express',
      'Node.js',
      'Go',
      'React',
      'Material design'
    ]
  },
  dfa: {
    title: 'DocFlow Assist',
    info: 'is a collection of auxiliary endpoints and back-end services for DocFlow',
    role: 'Developed the full-stack web application',
    points: [
      'Converts files from TIFF to PDF format, places copies in network folders, uploads to appropriate folder in Google Drive, then uses the Notification Service to email the associated sales representative',
      'Back-end module to generate PDF files with embedded QR code, along with a web page that allows users to specify the data to be contained in the PDF',
      'Periodic processs to check for emails from a specific sender and parse its contents',
      'Fetches files from AWS S3, decrypts, converts from TIFF to PDF, and makes available to users, along with a web page for users to specify the file to download',
      'Mitigated connection timeouts and spikes in server load by using periodic tasks to process queued requests',
      'Periodic process to clean up aged files'
    ],
    tags: [
      'Front-end',
      'Back-end',
      'React',
      'Node.js',
      'Express',
      'MongoDB',
      'Google API (Drive)',
      'Google API (Gmail)',
      'AWS (S3)',
      'Material design'
    ]
  },
  se: {
    title: 'SuperEye',
    info: 'is a document recognition API for automated indexing',
    role: 'Developed the API server',
    points: [
      'Basic document recognition using a set of document features',
      'Recognizes 9 different documents',
      'Endpoint to decode QR codes'
    ],
    tags: [
      'Back-end',
      'Node.js',
      'AWS (EC2)',
      'MongoDB',
      'Google API (Vision)'
    ]
  },
  ib: {
    title: 'iBreathe API',
    info: 'is the back-end for the iBreathe iOS app',
    role: 'Developed the API server',
    points: [
      'Built session, user, and medicine management features',
      'Designed a lightweight prescription management model based on templates',
      'User creation via Google account or standard email-password combo, and auto emails with verification link for the latter',
      'Integrated existing endpoints from another related, internal application into the API server',
      "Provided an admin endpoint for linking/merging the app's data with that of another related, internal application",
      'Practiced test-driven development with Mocha and Chai'
    ],
    tags: [
      'Back-end',
      'Node.js',
      'AWS (EC2)',
      'MongoDB',
      'Mocha & Chai',
      'Google API (Gmail)',
      'Google API (Login)'
    ]
  },
  dtb: {
    title: 'DeliveryTrack Board',
    info: "is an internal web page that displays live locations of the company's delivery drivers on a map",
    role: "Designed and developed the web page, given access to drivers' geocoordinate data",
    points: [
      "Toggle-able traffic layer so that dispatchers are more cognizant of drivers' driving conditions",
      'Blinking markers for drivers who are currently busy at a patient stop',
      "View the driver's path trace on the map on any specified day",
      "View the driver's stops for the day on the map, as well as their work order information such as items being delivered",
      "View the driver's current status and status history--the timestamps and positions on the map where status changes occurred (en route, arrived, etc.)",
      'Filter drivers by branch and branch region',
      'Numerous minor features, such as being able to center on the driver by clicking his/her name on the fixed side menu'
    ],
    tags: [
      'Front-end',
      'MongoDB',
      'React',
      'Google API (Maps)',
      'Material design'
    ]
  },
  im: {
    title: 'Inventory Management',
    info: 'is a full-stack web application used to manage inventory',
    role: 'Developed the full-stack web application',
    points: [
      'Basic dashboard web site for managing items and personnel',
      'Basic CRUD and search functionality',
      'JWT-based authentication'
    ],
    tags: [
      'Front-end',
      'Back-end',
      'React',
      'MongoDB',
      'Google API (Login)',
      'Material design'
    ]
  },
  df: {
    title: 'DocFlow',
    info: 'is an internal document processing application.',
    role: 'Secondary developer and technical support',
    points: [
      'Set up a test instance and wrote scripts to automate the setup and updates, which clones necessary repos, checks out to a development branch, installs dependencies, takes Mongo dumps of the production database and restores to the test server',
      'Authored documention on the architecture and support, including common errors and their solutions',
      'Made minor bug fixes and modifications'
    ],
    tags: [
      'Bash',
      'MongoDB'
    ]
  },
  dt: {
    title: 'DeliveryTrack',
    info: 'is the back-end for the DeliveryTrack mobile app.',
    role: 'Secondary developer',
    points: [
      'Integrated calls to Notification Service in error handling code, which resulted in discovery of errors previously unknown',
      'Replicated the back-end on a new AWS EC2 and modified it to run on HTTPS',
      'Developed 6 endpoints for updating various parts of a work order, as well as allowing for batch update operations for offline support',
      'Replaced a PHP-based wrapper for MSSQL integration with one based on Node.js'
    ],
    tags: [
      'Back-end',
      'AWS (EC2)',
      'Express'
    ]
  }
}

