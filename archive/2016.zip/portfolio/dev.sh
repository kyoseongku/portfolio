#! /bin/bash

webpack --config ./webpack.dev.config.js
spd-say -t female2 "refresh your bacons"
nodemon ./src/server.js
