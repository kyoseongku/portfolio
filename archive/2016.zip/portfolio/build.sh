#! /bin/bash

rm kyoseong.zip;
webpack -p;
zip -r kyoseong.zip .babelrc build.sh development.sh .ebextensions .gitignore nodemon.json package.json README.md src webpack.config.js webpack.dev.config.js;
