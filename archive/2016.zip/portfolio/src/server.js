const http = require('http'),
  express = require('express'),
  path = require('path');

const app = express();
const server = http.createServer(app);

const bParser = require('body-parser'),
  helmet = require('helmet'),
  favicon = require('serve-favicon'),
  io = require('socket.io')(server),
  router = require('./controllers/router.js'),
  wsHandler = require('./controllers/websockets.js');

app.set('port', (app.get('env') === 'production') ? process.env.PORT : 3000);
app.set('rootdir', __dirname);

app.use(bParser.json());
app.use(bParser.urlencoded({ extended: false }));
app.use(favicon(path.join(__dirname, 'static', 'favicon.ico')));
app.use(helmet({
  noCache: false // For Edge compatibility
}));

// Check request source before serving static files
app.use(router.aws(app.get('env')));
app.use(express.static(path.join(__dirname, 'static')));

// Back-end API route handler
router.handle(app);

// WebSockets handler
wsHandler(io);

server.on('error', (err) => {
  console.log('server err', err);
});

server.listen(app.get('port'), () => {
  console.log(`listening on port ${app.get('port')} in ${app.get('env')} mode`);
});