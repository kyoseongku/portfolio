const path = require('path'),
  axios = require('axios');

const staticRoutes = ['css', 'fonts', 'js'];

module.exports = {

// AWS-specific redirection
aws: (env) => {
  return (req, res, next) => {
    // Let dev mode pass
    if(env === 'development' && req.headers.host === 'localhost:3000')
      return next();

    // Skip check on static files
    if(staticRoutes.indexOf(req.path.split('/')[1]) >= 0)
      return next();

    if(req.headers.host !== 'www.kyoseong.com'
      || !(req.headers['x-forwarded-port'] && Number(req.headers['x-forwarded-port']) === 443)
      || !(req.headers['x-forwarded-proto'] && req.headers['x-forwarded-proto'] === 'https')) 
    {
      // Redirect using preferred protocol and host
      return res.redirect('https://www.kyoseong.com'+req.originalUrl);
    }

    next();
  }
},



handle: (app) => {
  // React routing GET catch-all
  app.get('*', (req, res, next) => {
    return res.sendFile(path.resolve(app.get('rootdir'), 'static', 'index.html'));
  });

  app.post('/chat', (req, res, next) => {
    res.send('https://aistein.firebaseio.com/chat');
  });

  app.post('/vchat', (req, res, next) => {
    axios.post('https://service.xirsys.com/ice', {
      ident: 'kyoseong',
      secret: '82875306-712f-11e6-a26d-4afb12a84f55',
      domain: 'www.kyoseong.com',
      application: 'default',
      room: 'default',
      secure: 1
    }).then((response) => {
      if(response.data.s == 200)
        res.send(response.data.d);
      else
        res.status(response.data.s).send(response.data);
    }).catch((err) => {
      res.status(500).send(err);
    });
  });

  // Error handler
  app.use((err, req, res, next) => {
    console.log('router err', err);
    res.redirect('/');
  });
}
};