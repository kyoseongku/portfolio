module.exports = function(io) {
  io.on('connection', (socket) => {
    socket.on('new', (data) => {
      socket.broadcast.emit(data.room, {
        name: data.name,
        type: data.type
      });
    });

    socket.on('exchange', (data) => {
      socket.broadcast.emit(data.room, {
        name: data.name,
        type: data.type,
        data: data.sdp || data.ice
      });
    });

    socket.on('chat', (data) => {
      io.sockets.emit(data.room, {
        name: data.name,
        text: data.text,
        time: data.time
      });
    });
  });
};