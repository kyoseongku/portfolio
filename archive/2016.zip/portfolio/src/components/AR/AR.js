import React from 'react';
import styles from './style.css';
import * as actions from './actions.js';



class Description extends React.Component {
  render() {
    return (
      <div className={styles.projWrapper}>
        <div className="container">
          <div className="card">
            <div className="card-content">
              <div className={styles.projHeader}>
                <h5 className="light">Simple augmented reality with color tracking</h5>
                <p>Oct. 2016</p>
              </div>
              <p><b>Description:</b></p>
              <p>I came across a WebGL library (three.js) which made me want to build something simple yet interesting with it. While searching for an idea, I also came across a tracking library (tracking.js) and decided to combine the two with media capture. This is the result of my creativity.</p>
              <br/>
              <p><b>Google Chrome on a computer is required.</b> Currently unavailable on mobile, and I haven't tested on tablet.</p>
              <br/>
              <p><b>Instructions:</b></p>
              <p>Hold up a red, green, and/or blue object to the camera. You can use your smartphone to display the colors, but glare/reflection can interfere. The detected colors and their RGB values are red (R, &lt;R-50, &lt;R-50), green (&lt;G-50, G, &lt;G-50), and blue (&lt;B-50, &lt;B-50, B). Bright--not faint--colors like these <a href="https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Red_flag.svg/2000px-Red_flag.svg.png" target="_blank">red</a>, <a href="https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Solid_green.svg/2000px-Solid_green.svg.png" target="_blank">green</a>, and <a href="https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Solid_blue.svg/2000px-Solid_blue.svg.png" target="_blank">blue</a> work best.</p>
              <br/>
              <p>Below is a demo video served from my secure/HTTPS content distribution network (AWS S3 via CloudFront)</p>
              <br/>
              <video id="arDemoVideo" controls poster="https://dysrf6t0c7f2p.cloudfront.net/ar_poster.png" className="responsive-video">
                <source src="https://dysrf6t0c7f2p.cloudfront.net/ar.mp4" type="video/mp4"/>
              </video>
              <div className="row center">
                <div className="col s12 m6 offset-m3 l4 offset-l4">
                  <a id="start" className={`btn blue ${styles.button}`}>Start</a>
                </div>
              </div>
              <p><b>Sources:</b></p>
              <p><a href="https://www.youtube.com/watch?v=yLtssSLNhWk" target="_blank">Harambe song (USMC version)</a></p>
              <p><a href="https://www.youtube.com/watch?v=d9TpRfDdyU0" target="_blank">Pen Pineapple Apple Pen</a></p>
              <p><a href="https://clara.io/view/7491ff2a-2913-4be3-8f79-faf597b5d49c" target="_blank">My Little Pony Model</a></p>
            </div>
            <div className="card-action"><a href="/#showcase">Return to homepage</a></div>
          </div>
        </div>
      </div>
    );
  }
}



class WGLCanvas extends React.Component {
  render() {
    return (
      <div>
        <div className={styles.placeholder}>
          <h5 className="light white-text">Loading...</h5>
        </div>
        <div className={styles.webGLWrapper}>
          <canvas id="webGLCanvas"></canvas>
        </div>
        <div className={styles.mediaWrapper}>
          <audio id="harambe" controls>
            <source src="https://dysrf6t0c7f2p.cloudfront.net/harambe.mp3" type="audio/mpeg"/>
          </audio>
          <canvas id="localCanvas"></canvas>
          <canvas id="ppapCanvas"></canvas>
          <video id="ppapVideo" controls>
            <source src="media/ppap.mp4" type="video/mp4"/>
          </video>
          <video id="localVideo" autoPlay></video>
        </div>
      </div>
    );
  }
}



export default class AR extends React.Component {
  constructor(props) {
    super(props);
    this.state = {showDesc: true};
  }

  componentDidMount() {
    this.handleResize();
    $(window).on('resize', this.handleResize);
    
    $('#start').on('click', this.init3D.bind(this));

    $('#arDemoVideo').click(() => {
      var vidElem = document.getElementById('arDemoVideo');
      (vidElem.paused) ? vidElem.play() : vidElem.pause();
    });

    $('#arDemoVideo').on('loadeddata', this.handleResize);
  }

  componentWillUnmount() {
    $(window).off('resize');
  }

  handleResize() {
    $(`.${styles.projWrapper}`).css('min-height', $(window).height());
    $(`.${styles.projWrapper}`).css('min-width', $(window).width());
  }

  init3D() {
    $(`.${styles.placeholder}`).show();
    $(`.${styles.placeholder}`).css('min-height', $(window).height());
    $(`.${styles.placeholder}`).css('min-width', $(window).width());
    this.setState({showDesc: false});

    actions.init()
    .then(() => {
      $(`.${styles.placeholder}`).remove();
    }).catch((err) => {
      console.log(err);
      alert('Error initializing');
    });

    $(window).on('resize', actions.handleResize);
  }

  render() {
    return (
      <div>
        {this.state.showDesc && <Description />}
        <WGLCanvas />
      </div>
    );
  }
}