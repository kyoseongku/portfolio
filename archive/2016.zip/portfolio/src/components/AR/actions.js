// With help from http://stemkoski.github.io/Three.js/

let webGLCanvas, tracker, scene, camera, renderer,
    cameraZ,
    video = {},
    ppap = {},
    harambe = {},
    luna = {};



// Defines the detected colors and the functions to execute when they're detected and no longer detected
let colors = {
  red: {
    max: {area: 0},
    validRGB: (r, g, b) => { return r-g > 50 && r-b > 50 && Math.abs(g-b) < 50 },
    onDetect: (max) => {
      harambe.audio.play();
      harambe.img.traverse((obj) => { obj.visible = true });
      harambe.img.position.set(
        -(video.width/2)+(video.xFactor*max.rect.x)+harambe.radius,
        (video.height/2)-(video.yFactor*max.rect.y)-harambe.radius,
        2
      );
    },
    onDisappear: () => {
      harambe.audio.pause();
      harambe.img.traverse((obj) => { obj.visible = false });
    }
  },
  green: {
    max: {area: 0},
    validRGB: (r, g, b) => { return g-r > 50 && g-b > 50 && Math.abs(r-b) < 50 },
    onDetect: (max) => {
      ppap.video.play();
      ppap.mesh.traverse((obj) => { obj.visible = true });
      ppap.mesh.position.set(
        -(video.width/2)+(video.xFactor*max.rect.x)+(ppap.width/2),
        (video.height/2)-(video.yFactor*max.rect.y)-(ppap.height/2),
        1
      );
    },
    onDisappear: () => {
      ppap.video.pause();
      ppap.context.clearRect(0, 0, ppap.canvas.width, ppap.canvas.height);
      ppap.mesh.traverse((obj) => { obj.visible = false });
    }
  },
  blue: {
    max: {area: 0},
    validRGB: (r, g, b) => { return b-r > 50 && b-g > 50 && Math.abs(r-g) < 50 },
    onDetect: (max) => {
      luna.obj.traverse((obj) => { obj.visible = true });
      luna.obj.position.set(
        -(video.width/2)+(video.xFactor*max.rect.x)+(luna.width/2),
        (video.height/2)-(video.yFactor*max.rect.y)-(luna.height/2),
        luna.width/2
      );
    },
    onDisappear: () => {
      luna.obj.traverse((obj) => { obj.visible = false });
    }
  }
};



const initHarambe = () => {
  return new Promise((resolve, reject) => {
    harambe.audio = document.getElementById('harambe');

    let setup = () => {
      let loader = new THREE.TextureLoader();
      loader.crossOrigin = '';
      loader.load('https://dysrf6t0c7f2p.cloudfront.net/harambe.png', (texture) => {
        harambe.texture = texture;
        harambe.geometry = new THREE.SphereGeometry(harambe.radius, 16, 12);
        harambe.material = new THREE.MeshBasicMaterial({ map: harambe.texture });
        harambe.img = new THREE.Mesh(harambe.geometry, harambe.material);
        resolve();
      });
    };

    if(harambe.audio.readyState == 4)
      setup();
    else
      $('#harambe').on('loadeddata', setup);
  });
};

const initPPAP = () => {
  return new Promise((resolve, reject) => {
    ppap.video = document.getElementById('ppapVideo');
    ppap.canvas = document.getElementById('ppapCanvas');

    let setup = () => {
      ppap.canvas.height = ppap.video.videoHeight;
      ppap.canvas.width = ppap.video.videoWidth;
      ppap.context = ppap.canvas.getContext('2d');
      ppap.texture = new THREE.Texture(ppap.canvas);
      ppap.texture.minFilter = THREE.LinearFilter;
      ppap.texture.magFilter = THREE.LinearFilter;
      ppap.mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(ppap.canvas.width, ppap.canvas.height),
        new THREE.MeshBasicMaterial({ map: ppap.texture })
      );
      ppap.mesh.position.set(0, 0, 1);
      ppap.mesh.scale.set(ppap.const, ppap.const, 1);

      let ppapBounds = new THREE.Box3().setFromObject(ppap.mesh);
      ppap.width = ppapBounds.getSize().x;
      ppap.height = ppapBounds.getSize().y;

      resolve();
    };

    if(ppap.video.readyState == 4)
      setup();
    else
      $('#ppapVideo').on('loadeddata', setup);
  });
};

const initLuna = () => {
  return new Promise((resolve, reject) => {
    let loader = new THREE.ObjectLoader();
    loader.setCrossOrigin('');
    loader.load('https://dysrf6t0c7f2p.cloudfront.net/luna2.json', (obj) => {
      luna.obj = obj;
      luna.obj.scale.set(luna.const, luna.const, luna.const);

      let lunaBounds = new THREE.Box3().setFromObject(luna.obj);
      luna.width = lunaBounds.getSize().z;
      luna.height = lunaBounds.getSize().y;

      resolve();
    });
  });
};

const initVideo = () => {
  return new Promise((resolve, reject) => {
    navigator.mediaDevices.getUserMedia({audio: false, video: true})
    .then((stream) => {
      video.element = document.getElementById('localVideo');
      video.canvas = document.getElementById('localCanvas');
      video.element.srcObject = stream;

      let setup = () => {
        video.canvas.height = video.const;
        video.canvas.width = video.const*video.element.videoWidth/video.element.videoHeight;
        video.context = video.canvas.getContext('2d');
        video.texture = new THREE.Texture(video.canvas);
        video.texture.minFilter = THREE.LinearFilter;
        video.texture.magFilter = THREE.LinearFilter;
        video.mesh = new THREE.Mesh(
          new THREE.PlaneGeometry(video.const*video.canvas.width/video.canvas.height, video.const),
          new THREE.MeshBasicMaterial({ map: video.texture })
        );
        video.mesh.position.set(0, 0, 0);
        
        let videoBounds = new THREE.Box3().setFromObject(video.mesh);
        video.width = videoBounds.getSize().x;
        video.height = videoBounds.getSize().y;

        video.xFactor = video.width/video.element.videoWidth;
        video.yFactor = video.height/video.element.videoHeight;

        resolve();
      };

      if(video.element.readyState == 4)
        setup();
      else
        $('#localVideo').on('loadeddata', setup);
    }).catch(reject);
  });
};



// Initialize color tracking
const initTracking = () => {
  // Define custom colors
  tracking.ColorTracker.registerColor('red', colors.red.validRGB);
  tracking.ColorTracker.registerColor('green', colors.green.validRGB);
  tracking.ColorTracker.registerColor('blue', colors.blue.validRGB);

  tracker = new tracking.ColorTracker(Object.keys(colors));

  tracker.on('track', (event) => {
    // No colors detected at all
    if(event.data.length === 0) {
      for(let c in colors) {
        colors[c].max.area = 0;
        colors[c].onDisappear();
      }
      return;
    }

    event.data.forEach((rect) => {
      // For each detected color, store the largest rectangle by area
      if(rect.height*rect.width > colors[rect.color].max.area) {
        colors[rect.color].max.area = rect.height*rect.width;
        colors[rect.color].max.rect = rect;
      }
    });

    for(let c in colors) {
      if(colors[c].max.area > 0)
        colors[c].onDetect(colors[c].max);
      else // Clear the color(s) not detected during this iteration
        colors[c].onDisappear();

      colors[c].max.area = 0;
    }
  });

  tracking.track('#localVideo', tracker);
};



const init3D = () => {
  webGLCanvas = document.getElementById('webGLCanvas');
  webGLCanvas.height = $(window).height();
  webGLCanvas.width = $(window).width();

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(45, webGLCanvas.width/webGLCanvas.height, 1, 1000);
  scene.add(camera);

  renderer = new THREE.WebGLRenderer({ canvas: webGLCanvas });
  renderer.setSize(webGLCanvas.width, webGLCanvas.height);

  let light = new THREE.PointLight(0xffffff);
  light.position.set(cameraZ/2, cameraZ/2, cameraZ/2);
  scene.add(light);

  scene.add(video.mesh);
  scene.add(harambe.img);
  scene.add(ppap.mesh);
  scene.add(luna.obj);

  camera.position.set(0, 0, cameraZ);
  camera.lookAt(video.mesh.position);
};



const animate = () => {
  video.context.clearRect(0, 0, video.canvas.width, video.canvas.height);
  video.context.drawImage(video.element, 0, 0, video.canvas.width, video.canvas.height);
  video.texture.needsUpdate = true;

  if(!ppap.video.paused) {
    ppap.context.clearRect(0, 0, ppap.canvas.width, ppap.canvas.height);
    ppap.context.drawImage(ppap.video, 0, 0, ppap.canvas.width, ppap.canvas.height);
    ppap.texture.needsUpdate = true;
  }

  harambe.img.rotation.y += 0.05;
  luna.obj.rotation.y += 0.05;

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
};



export function init() {
  setConsts();

  return new Promise((resolve, reject) => {
    Promise.all([
      initHarambe(),
      initPPAP(),
      initLuna(),
      initVideo()
    ]).then(() => {
      init3D();
      initTracking();
      animate();
      resolve();
    }).catch(reject);
  });
};



const setConsts = () => {
  let h = $(window).height();
  let w = $(window).width();

  if(webGLCanvas) {
    webGLCanvas.height = h;
    webGLCanvas.width  = w;
  }

  if(video.element && video.height) {
    video.xFactor = video.width/video.element.videoWidth;
    video.yFactor = video.height/video.element.videoHeight;
  }

  cameraZ = h/2;
  video.const = h/2.5;
  harambe.radius = h/25;
  ppap.const = 200/h;
  luna.const = 7250/h;
};



export function handleResize() {
  setConsts();

  console.log('TODO scale objects');

  camera.aspect = webGLCanvas.width/webGLCanvas.height;
  renderer.setSize(webGLCanvas.width, webGLCanvas.height);
};