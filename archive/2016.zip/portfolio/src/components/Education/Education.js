import React from 'react';
import styles from './style.css';

export default class Education extends React.Component {
  render() {
    return (
      <div className='container'>
        <div className='row'>
          <div className='col s12 m6'>
            <div className={styles.intro}>
              <img src='https://dysrf6t0c7f2p.cloudfront.net/ucla_logo.png'/>
              <h4 className='light'>Computer Science, B.S.</h4>
              <p><b>University of California, Los Angeles</b></p>
              <p>Received Dec. 2015</p>
            </div>
          </div>
          <div className='col s12 m6'>
            <div className={styles.classes}>
              <h4 className='light'>Relevant coursework</h4>
              <p>Algorithms &amp; Complexity</p>
              <p>Artificial Intelligence</p>
              <p>Computer Graphics</p>
              <p>Database Systems</p>
              <p>Data Structures</p>
              <p>Formal Languages &amp; Automata Theory</p>
              <p>Machine Architecture</p>
              <p>Network Fundamentals</p>
              <p>Object-oriented Programming</p>
              <p>Operating Systems</p>
              <p>Programming Languages</p>
              <p>Software Engineering</p>
              <p>Web Applications</p>
              <p>---</p>
              <p>Entrepreneurship for Engineers</p>
              <p>Finance and Marketing for Engineers</p>
              <p>Systems Engineering</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}