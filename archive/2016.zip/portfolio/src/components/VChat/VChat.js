import React from 'react';
import styles from './style.css';
import * as actions from './actions.js';



class Description extends React.Component {
  render() {
    return(
      <div className="container">
        <div className="card">
          <div className="card-content">
            <div className={styles.projHeader}>
              <h5 className="light">Video chat and 3D fiddle</h5>
              <p>Sep. 2016</p>
            </div>
            <div className={styles.projDesc}>
              <p><b>Description:</b></p>
              <p>Basic 1-to-1, peer-to-peer video chat using WebRTC and Socket.io in 3D space. <b>Google Chrome is required</b>, as I haven't tested or adapted to other browsers.</p>
              <br/>
              <p>Your name must be different than the other participant's, and both participants must use the same room name in order to be connected. You can also open two tabs and call yourself.</p>
              <br/>
              <p>You'll see your video feed on an orbiting, rotating sphere until your peer connects.</p>
              <form>
                <div className="row">
                  <div className="input-field col s12 m4 l4">
                    <input id="name" type="text"/>
                    <label htmlFor="name">Your name</label>
                  </div>
                  <div className="input-field col s12 m4 l4">
                    <input id="room" type="text"/>
                    <label htmlFor="room">Room name</label>
                  </div>
                  <div className="input-field col s12 m4 l4">
                    <a id="call" className={`btn blue ${styles.callBtn}`}>Call</a>
                  </div>
                </div>
              </form>
            </div>
            <div className="card-action"><a href="/#showcase">Return to homepage</a></div>
          </div>
        </div>
      </div>
    )
  }
}



class WGLCanvas extends React.Component {
  render() {
    return (
      <div>
        <div className={styles.canvasWrapper}>
          <canvas id="webGLCanvas"></canvas>
        </div>
        <div className={styles.mediaWrapper}>
          <canvas id="localCanvas"></canvas>
          <canvas id="remoteCanvas"></canvas>
          <video id="localVideo" autoPlay muted></video>
          <video id="remoteVideo" autoPlay></video>
        </div>
      </div>
    )
  }
}



export default class VChat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {showDesc: true};

    this.init3D = this.init3D.bind(this);
  }

  componentDidMount() {
    this.handleResize();
    $(window).on('resize', this.handleResize);

    $(window).on('beforeunload', () => {
      if(this.state.pc)
        this.state.pc.close();
    });

    $('#call').click(() => {
      this.initCall()
    });

    $('#name, #room').on('keypress', (event) => {
      if(event.keyCode == 13) {
        event.preventDefault();
        this.initCall();
      }
    });
  }

  componentWillUnmount() {
    $(window).off('resize');
  }

  handleResize() {
    $(`.${styles.projWrapper}`).css('min-height', $(window).height());
  }

  initCall() {
    let name = $('#name').val();
    if(!name || name === '') {
      alert("Name is required");
      return;
    }

    let room = $('#room').val();
    if(!room || room === '') {
      alert("Room name is required");
      return;
    }

    $('#call').addClass('disabled');
    $('#call').text('Loading...');

    let self = this;
    actions.initCall(name, room, this.onPeerConnect.bind(this))
    .then((result) => {
      $('#localVideo').on('loadeddata', self.init3D);
      self.setState({ pc: result.pc, showDesc: false });
    }).catch((err) => {
      console.log(err);
      alert('Initialization error');
    });
  }

  init3D() {
    $(`.${styles.projWrapper}`).css('padding', 0);
    actions.init3D();
    $(window).on('resize', actions.handleResize);
  }

  onPeerConnect() {
    $('#remoteVideo').on('loadeddata', actions.initRemote);
  }

  render() {
    return (
      <div className={styles.projWrapper}>
        {this.state.showDesc && <Description />}
        <WGLCanvas />
      </div>
    )
  }
}