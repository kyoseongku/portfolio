import axios from 'axios';
import * as adapter from 'webrtc-adapter';

// Video call related code
let pc, socket, initICE = [], name, room;

const initXirsys = () => {
  return new Promise((resolve, reject) => {
    axios.post('/vchat')
    .then((response) => {
      resolve(response.data);
    }).catch((err) => {
      reject({ where: 'initXirsys', what: err });
    });
  });
};



const onSocketInit = (onFail) => {
  pc.createOffer((desc) => {
    pc.setLocalDescription(desc, () => {
      socket.emit('exchange', {
        name: name,
        room: room,
        type: 'offer',
        sdp: JSON.stringify(desc)
      });
    }, (err) => {onFail({ where: 'setLocalDesc', what: err })});
  }, (err) => {onFail({ where: 'createOffer', what: err })},
  {offerToReceiveAudio: 1, offerToReceiveVideo: 1});
};



const onSocketOffer = (desc, onFail) => {
  pc.setRemoteDescription(new RTCSessionDescription(desc), () => {
    pc.createAnswer((desc) => {
      pc.setLocalDescription(desc, () => {
        socket.emit('exchange', {
          name: name,
          room: room,
          type: 'answer',
          sdp: JSON.stringify(desc)
        });
      }, (err) => {onFail({ where: 'setLocalDesc', what: err })});
    }, (err) => {onFail({ where: 'createAnswer', what: err })});
  }, (err) => {onFail({ where: 'setRemoteDesc', what: err })});
};



const onSocketICE = (candidates, onFail) => {
  // Only set remote peer's ICE when finished gathering local ICE
  if(pc.iceGatheringState === 'complete') {
    for(let c in candidates)
      pc.addIceCandidate(new RTCIceCandidate(candidates[c]), ()=>{}, (err) => {onFail({ where: 'addIceCandidate', what: err })});
  }
  else
    setTimeout(onSocketICE, 100, candidates, onFail);
};



export function initCall(n, r, onPeerConnect) {
  name = n;
  room = r;

  return new Promise((resolve, reject) => {
    initXirsys()
    .then((response) => {
      pc = new RTCPeerConnection(response);
      return navigator.mediaDevices.getUserMedia({video: true, audio: true});
    }).then((stream) => {
      socket = io.connect('/');

      socket.emit('new', {
        name: name,
        room: room,
        type: 'init'
      });

      socket.on(room, (data) => {
        if(data.type === 'init')
          onSocketInit(reject);
        else if(data.type === 'offer')
          onSocketOffer(JSON.parse(data.data), reject);
        else if(data.type === 'answer')
          pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(data.data)), ()=>{}, reject);
        else if(data.type === 'ice')
          onSocketICE(JSON.parse(data.data), reject);
      });

      document.getElementById('localVideo').srcObject = stream;

      pc.addStream(stream);

      pc.onaddstream = (event) => {
        document.getElementById('remoteVideo').srcObject = event.stream;
      };

      pc.onicecandidate = (event) => {
        if(event.candidate)
          initICE.push(event.candidate);
        else if(event && !event.candidate) {
          socket.emit('exchange', {
            room: room,
            name: name,
            type: 'ice',
            ice: JSON.stringify(initICE)
          });
        }
      };

      pc.oniceconnectionstatechange = () => {
        if(pc.iceConnectionState === 'connected') {
          onPeerConnect();
          socket.disconnect();
        }
      };

      resolve({pc: pc});
    }).catch(reject);
  });
};



// 3D related code
let webGLCanvas, local = {}, remote = {}, scene, camera, renderer, cameraZ;

const animate = (t) => {
  local.context.clearRect(0, 0, local.canvas.width, local.canvas.height);
  local.context.drawImage(local.video, 0, 0, local.canvas.width, local.canvas.height);

  local.x = local.amp*Math.cos(local.omega*t);
  local.y = local.amp*Math.sin(local.omega*t);
  local.z = local.amp*Math.cos(local.omega*t);

  local.mesh.rotation.y += local.phi;
  local.mesh.position.set(local.x, local.y, local.z);

  if(local.texture)
    local.texture.needsUpdate = true;

  if(remote.context) {
    remote.context.clearRect(0, 0, remote.canvas.width, remote.canvas.height);
    remote.context.drawImage(remote.video, 0, 0, remote.canvas.width, remote.canvas.height);

    remote.mesh.rotation.x += remote.phi;
    remote.mesh.rotation.y += remote.phi;

    if(remote.texture) 
      remote.texture.needsUpdate = true;
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
};



export function init3D() {
  webGLCanvas = document.getElementById('webGLCanvas');
  handleResize();

  local.video = document.getElementById('localVideo');
  local.canvas = document.getElementById('localCanvas');
  local.canvas.height = local.const;
  local.canvas.width = local.const*local.video.videoWidth/local.video.videoHeight;
  local.context = local.canvas.getContext('2d');
  local.phi = 0.025;
  local.omega = 0.001;

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(45, webGLCanvas.width/webGLCanvas.height, 1, 1000);
  renderer = new THREE.WebGLRenderer({ canvas: webGLCanvas });
  renderer.setSize(webGLCanvas.width, webGLCanvas.height);
  scene.add(camera);

  let light = new THREE.PointLight(0xffffff);
  light.position.set(cameraZ, cameraZ, cameraZ);
  scene.add(light);

  local.texture = new THREE.Texture(local.canvas);
  local.texture.minFilter = THREE.LinearFilter;
  local.texture.magFilter = THREE.LinearFilter;
  local.mesh = new THREE.Mesh(
    new THREE.SphereGeometry(local.canvas.width/75, 16, 12),
    new THREE.MeshBasicMaterial({ map: local.texture })
  );

  scene.add(local.mesh);

  camera.position.set(0, 0, cameraZ);
  camera.lookAt(new THREE.Vector3(0, 0, 0));

  animate();
};



export function initRemote() {
  remote.video = document.getElementById('remoteVideo');
  remote.canvas = document.getElementById('remoteCanvas');
  remote.canvas.height = remote.const;
  remote.canvas.width = remote.const*remote.video.videoWidth/remote.video.videoHeight;
  remote.context = remote.canvas.getContext('2d');
  remote.phi = 0.0125;

  remote.texture = new THREE.Texture(remote.canvas);
  remote.texture.minFilter = THREE.LinearFilter;
  remote.texture.magFilter = THREE.LinearFilter;
  let material = new THREE.MeshBasicMaterial({ map: remote.texture });
  remote.mesh = new THREE.Mesh(
    new THREE.BoxGeometry(remote.canvas.width/20, remote.canvas.width/20, remote.canvas.width/20),
    new THREE.MeshFaceMaterial([ material, material, material, material, material, material ])
  );
  remote.mesh.position.set(0, 0, 0);

  scene.add(remote.mesh);
};



export function handleResize() {
  let h = $(window).height();
  let w = $(window).width();

  if(webGLCanvas) {
    webGLCanvas.height = h;
    webGLCanvas.width  = w;
  }

  cameraZ = h/10;
  local.amp = h/40;
  local.const = h/2.5;
  remote.const = h/2.5;

  console.log('TODO scale objects');

  if(camera && renderer) {
    camera.aspect = webGLCanvas.width/webGLCanvas.height;
    renderer.setSize(webGLCanvas.width, webGLCanvas.height);
  }
};