export const sched = {
  title: 'Desktop Scheduling Application (Java)',
  date: 'Summer 2013 - Spring 2014',
  src: 'https://www.youtube.com/embed/V-vss6cpjsk',
  desc: ["This project allows users to set their availabilities for a work week and exports the data as a Microsoft Excel file."],
  note: ["There is no sound, so feel free to skip through or watch it at 2x speed."],
  motiv: [
    "Every week, the employees at the UCLA Computer Store filled out a paper form that indicated their availability for the following week, and the manager scheduled the employees manually. I saw an opportunity to automate this process, so I began working on a GUI desktop application using Java.",
    "I planned to use Prolog to automatically compute a weekly work schedule based on the employees' availabilities and constraints (such as the minimum and maximum number of employees working concurrently), but I've decided not to continue with this project."
  ],
  repo: 'https://github.com/kyoseongku/Scheduler'
};

export const heli = {
  title: 'Desktop Helicopter Game (C++ and OpenGL)',
  date: 'Summer 2015',
  src: 'https://www.youtube.com/embed/gxRqHnwv_a0',
  desc: [
    "This project is based on an academic assignment for UCLA's Introduction to Computer Graphics course (174A).",
    "I expanded upon the original assignment for fun, which was a coded animation using C++, into a simple game where the player can maneuver a helicopter and fire missiles to shoot down giant bees while avoiding their stingers, sort of like a 3D Asteroid Blaster."
  ],
  note: ["There are no sound effects, and only the original animation video and my initial commit are available because my laptop crashed and I haven't backed up my files. The additional code I wrote allowed the user to maneuver the helicopter along the x and y axes and fire missiles."],
  repo: 'https://github.com/kyoseongku/heli'
}