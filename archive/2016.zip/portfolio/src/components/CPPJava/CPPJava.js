import React from 'react';
import styles from './style.css';
import * as texts from './text.js';

export default class CPPJava extends React.Component {
  render() {
    const obj = texts[this.props.which];

    let motiv = (obj.motiv) ? (
      <div>
        <br/>
        <p><b>Motivation:</b></p>
        {obj.motiv.map((m, i) => {return (<p key={i}>{m}</p>)})}
        <br/>
      </div>
      ) : (<br/>);

    return (
      <div className={styles.projWrapper}>
        <div className="container">
          <div className="card">
            <div className="card-content">
              <div className={styles.projHeader}>
                <h5 className="light">{obj.title}</h5>
                <p>{obj.date}</p>
              </div>
              <div className={styles.projYT}>
                <iframe src={obj.src} frameBorder="0" allowFullScreen=""></iframe>
              </div>
              <p><b>Description:</b></p>
              {obj.desc.map((d, i) => {return (<p key={i}>{d}</p>)})}
              {motiv}
              <p><b>Note:</b></p>
              {obj.note.map((n, i) => {return (<p key={i}>{n}</p>)})}
              <p><a href={obj.repo} target="_blank">Repository</a></p>
            </div>
            <div className="card-action">
              <a href="/#showcase">Return to homepage</a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}