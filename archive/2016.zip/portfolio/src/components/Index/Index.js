import React from 'react';
import {Link} from 'react-router';
import styles from './style.css';
import Section from '../Section/Section';

export default class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    this.handleResize();

    $(window).on('resize', () => {
      this.setState(this.handleResize());
    });

    setTimeout(() => {
      $(`.${styles.greetingWrapper} h1`).addClass('animated wobble');
    }, 250);
  }

  componentWillUnmount() {
    $(window).off('resize');
  }

  handleResize() {
    var dim = {
      minHeight: $(window).height(),
      greetTextHeight: $(`.${styles.greetingWrapper} h1`).height()+$(`.${styles.greetingWrapper} h3`).height()
    };

    $(`.${styles.greetingWrapper}`).css('min-height', dim.minHeight);
    $(`.${styles.greetingWrapper}`).css('padding-top', (dim.minHeight-dim.greetTextHeight)/2);

    return dim;
  }

  render() {
    return (
      <div>
        <div className={`${styles.greetingWrapper} center`}>
          <h1 className='light'>
            Hello
          </h1>
          <h3 className='light'>
            My name is Kyoseong (Austin), and I like to build things
          </h3>
        </div>
        <Section type='tech' minHeight={this.state.minHeight ? this.state.minHeight : $(window).height()} />
        <Section type='edu' minHeight={this.state.minHeight ? this.state.minHeight : $(window).height()} />
        <Section type='me' minHeight={this.state.minHeight ? this.state.minHeight : $(window).height()} />
      </div>
    );
  }
}