import React from 'react';
import styles from './style.css';



class Message extends React.Component {
  render() {
    let username = (!this.props.msg.name || this.props.msg.name  === '') ? 'anonymous' : this.props.msg.name;
    return (
      <div className={styles.chatMsg}>
        <span className={styles.chatUser}>{`${username} @ ${this.props.msg.time}`}</span>
        <span>{this.props.msg.text}</span>
      </div>
    );
  }
}



export default class Chat extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};

    this.initChat = this.initChat.bind(this);
    this.sendMsg = this.sendMsg.bind(this);
  }

  componentDidMount() {
    this.handleResize();
    $(window).on('resize', this.handleResize);

    let self = this;

    $('#room').on('keypress', (event) => {
      if(event.keyCode == 13) {
        event.preventDefault();
        self.initChat();
      }
    });

    $('#textarea').on('keypress', (event) => {
      if(event.keyCode == 13) {
        event.preventDefault();
        self.sendMsg();
      }
    });

    $(window).on('beforeunload', () => {
      if(this.state.socket)
        this.sendMsg('exit');
    });
  }

  componentWillUnmount() {
    $(window).off('resize');
  }

  handleResize() {
    $(`.${styles.projWrapper}`).css('min-height', $(window).height());
  }



  initChat() {
    let room = $('#room').val();
    if(!room || room === '') {
      alert('Please enter a room name');
      return;
    }

    let name = $('#name').val();
    if(!name || name === '')
      name = 'anonymous';

    let socket = io.connect('/');
    socket.on(room, this.receiveMsg.bind(this));

    this.setState({
      name: name,
      room: room,
      socket: socket,
      msgs: []
    }, () => {
      this.sendMsg('enter');
    });

    $('#chatContainer').show();
    $('#chatSelector').remove();
  }



  receiveMsg(data) {
    this.setState({ msgs: [...this.state.msgs, data] });
    $('#chatBox')[0].scrollTop = $('#chatBox')[0].scrollHeight;
  }



  sendMsg(enterExit) {
    let message;
    if(enterExit === 'enter')
      message = `${this.state.name} has joined the room ${this.state.room}`;
    else if(enterExit === 'exit')
      message = `${this.state.name} has left the room`;
    else
      message = $('#textarea').val().trim();

    if(message.length === 0)
      return;

    let dateObject = new Date();
    let date = `${Number(dateObject.getMonth())+1}/${dateObject.getDate()}`;
    let hours = dateObject.getHours();
    let minutes = dateObject.getMinutes();
    let meridiem = (hours >= 12) ? 'pm' : 'am';

    if(hours === 0)
      hours = 12;
    else if(hours > 12)
      hours -= 12;

    if(minutes < 10)
      minutes = '0'+minutes;

    this.state.socket.emit('chat', {
      room: this.state.room,
      name: this.state.name,
      text: message,
      time: `${date}, ${hours}:${minutes} ${meridiem}`
    });

    if(enterExit === 'exit')
      this.state.socket.disconnect();

    $('#textarea').val(null);
    $('#textarea').trigger('autoresize');
  }



  render() {
    return (
      <div className={styles.projWrapper}>
        <div className="container">
          <div className="card">
            <div className="card-content">
              <div className={styles.projHeader}>
                <h5 className="light">Real-time Chat App</h5>
                <p>Sep. 2015, expanded Sep. 2016</p>
              </div>
              <div className={styles.projDesc}>
                <p><b>Description:</b></p>
                <p>To see the web app in action, you need to open this demo on two or more devices and send messages.</p>
                <br/>
                <p>The fiddle has been updated from the HTML+Bootstrap of my old portfolio to Jade+Materialize, then again using React. The Firebase version has been replaced with a WebSockets version using Socket.io.</p>
              </div>
              <div id="chatSelector" className="row center">
                <div className="col s12 m6 l6">
                  <form>
                    <div className="row">
                      <div className="input-field col s12">
                        <input id="name" type="text" maxLength="32"/>
                        <label htmlFor="name">Your name (anonymous if blank)</label>
                      </div>
                      <div className="input-field col s12">
                        <input id="room" type="text" maxLength="64"/>
                        <label htmlFor="room">Room name (required for WebSockets)</label>
                      </div>
                    </div>
                  </form>
                </div>
                <div className="col s12 m6 l6">
                  <a className={`btn blue ${styles.chatBtn} disabled`}>Firebase version (removed)</a>
                  <p>Messages are stored and everyone can see them</p>
                  <br/>
                  <a className={`btn blue ${styles.chatBtn}`} onClick={this.initChat}>WebSockets version</a>
                  <p>Messages are not stored, and only participants in the same room can see them</p>
                </div>
              </div>
              <br/>
              <div id="chatContainer" className="row" style={{display: 'none'}}>
                <div className="col s12 m8 l9">
                  <div id="chatBox" className={styles.chatBox}>
                    {
                      this.state.msgs && this.state.msgs.map((msg, index) => {
                        return <Message key={index} msg={msg} />
                      })
                    }
                  </div>
                </div>
                <div className="col s12 m4 l3">
                  <form>
                    <div className="chat-input row">
                      <div className="input-field col s12">
                        <textarea id="textarea" maxLength="256" className="materialize-textarea"></textarea>
                        <label htmlFor="textarea">Type your message here</label>
                        <a className={`btn blue ${styles.chatBtn}`} onClick={this.sendMsg}>Enter</a>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div className="card-action"><a href="/#showcase">Return to homepage</a></div>
          </div>
        </div>
      </div>
    );
  }
}