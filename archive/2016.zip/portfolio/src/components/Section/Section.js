import React from 'react';
import styles from './style.css';
import Technical from '../Technical/Technical';
import Education from '../Education/Education';
import Me from '../Me/Me';

export default class Section extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      title: (this.props.type === 'tech') ? 'Technical' : (this.props.type === 'edu') ? 'Education' : 'Me',
      icon: (this.props.type === 'tech') ? 'build' : (this.props.type === 'edu') ? 'school' : 'perm_identity',
      iconColor: (this.props.type === 'tech') ? 'blue-grey-text' : (this.props.type === 'edu') ? 'light-blue-text' : 'amber-text',
      minHeight: this.props.minHeight,
      isAtTech: false
    };
  }

  handleResize() {
    $(`.${styles.edu}, .${styles.tech}, .${styles.me}`).css('min-height', this.props.minHeight);
  }

  componentDidMount() {
    this.handleResize();

    // Animation for each section icon
    let animationOffset = 0.25*$(window).height();

    let self = this;
    Materialize.scrollFire([
      {
        selector: `.${styles.tech} .${styles.sectionTitle} i`,
        offset: animationOffset,
        callback: () => {
          $(`.${styles.tech} .${styles.sectionTitle} i`).addClass('animated hinge');
          self.setState({isAtTech: true})
        }
      },
      {
        selector: `.${styles.edu} .${styles.sectionTitle} i`,
        offset: animationOffset,
        callback: () => {
          $(`.${styles.edu} .${styles.sectionTitle} i`).addClass('animated tada');
        }
      },
      {
        selector: `.${styles.me} .${styles.sectionTitle} i`,
        offset: animationOffset,
        callback: () => {
          $(`.${styles.me} .${styles.sectionTitle} i`).addClass('animated flip');
        }
      }
    ]);
  }

  componentDidUpdate(prevProps) {
    this.handleResize();
  }

  render() {
    return (
      <div className={styles[this.props.type]}>
        <div className={`${styles.sectionTitle} center`}>
          <i className={`material-icons large ${this.state.iconColor}`}>{this.state.icon}</i>
          <h2 className='light'>{this.state.title}</h2>
        </div>
        {
          (this.props.type === 'tech') ? (<Technical isViewing={this.state.isAtTech} />) : (this.props.type === 'edu') ? (<Education />) : (<Me sectionTitle={styles.sectionTitle} />)
        }
      </div>
    );
  }
}