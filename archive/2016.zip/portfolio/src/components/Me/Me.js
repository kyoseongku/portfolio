import React from 'react';
import styles from './style.css';

export default class Me extends React.Component {
  componentDidMount() {
    this.handleResize();
  }

  componentDidUpdate() {
    this.handleResize();
  }

  handleResize() {
    $(`.${styles.picWrapper}`).css('height', Math.max(400, $(window).height()-$(`.${this.props.sectionTitle}`).height()-140));

    // Resume button
    $(`.${styles.picCard}`).css('top', $(`.${styles.picWrapper}`).height()-$(`.${styles.picCard}`).height());
  }

  render() {
    return (
      <div className={styles.wrapper}>
        <div className='center'>
          <h5 className='light'>Click the button below for my resume, which contains my email and phone number</h5>
        </div>
        <div className='container'>
          <div className={`row ${styles.wrapperRow}`}>
            <div className='col s12 m6 offset-m3 l6 offset-l3'>
              <div className={styles.picWrapper}>
                <img className={styles.picImg} src='https://dysrf6t0c7f2p.cloudfront.net/me.jpg'/>
                <div className={`card indigo darken-3 ${styles.picCard}`} onClick={() => window.location.href = 'https://dysrf6t0c7f2p.cloudfront.net/resume-kyoseong_ku.pdf'}>
                  <div className='card-action center'>
                    <h5 className={`light ${styles.resume}`}>Click for a PDF version of my resume</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}