export const dylect = [
  {
    title: 'Back-end',
    text: [
      "Utilized Jade templating engine to separate the content from its presentation so that localization is as simple as translating the content files and design changes would require modifying just the presentation template",
      "Automated the sending of HTML emails from @dylect.com addresses upon user sign up and other notification events such as newly scheduled sessions and account removal",
      "Set up a persistent cookie separate from the one used for session management to keep track of traffic from affiliates in case visitors don't sign up during their first visit",
      "The forgot password functionality which emails the user a temporary password while preserving the old password in case someone other than the user was attempting to log in",
      "Account creation, removal, and update"
    ]
  },
  {
    title: 'Back-end, basic security',
    text: [
      "Implemented encrypted cookies and ensured that only one person can use the account at a time while avoiding lockout",
      "Encrypted sensitive information in the database using different keys and algorithms",
      "Developed a simple rate limiter using a circular buffer to help prevent denial-of-service attacks"
    ]
  },
  {
    title: 'Back-end, infrastructure',
    text: [
      "Organized the front-end JavaScript code as modules of closures and wrote a script to concatenate, minify, and obfuscate the source files. Currently migrating to React.js and Webpack",
      "Set up the infrastructure on AWS which includes: EC2 with automatic scaling and load balancing via Elastic Beanstalk, S3 with CloudFront on HTTPS, and DynamoDB with indexes for efficient queries as well as its schemata",
      "Implemented cron jobs using AWS Lambda, since multiple server instances can lead to multiple cron job executions"
    ]
  },
  {
    title: 'Front-end',
    text: [
      "Authored most of the HTML and CSS code using the Materialize framework. Currently migrating to React.js",
      "Created a composite carousel (a horizontal carousel with vertical scrollability in each element) with hidden scrollbars because scrollbars caused a cluttered look, and existing third-party solutions did not offer smooth mousewheel/touchpad support on desktop and swipe support on touch devices at the same time",
      "Detected if the visitor's cookies or JavaScript were disabled and displayed a notification with instructions on how to enable them"
    ]
  },
  {
    title: 'Peer-to-peer video chat',
    text: [
      "Developed a peer-to-peer, one-on-one video chat application into the browser which eliminates users' need to install software and diminishes server costs since the media data is transferred directly between the two participants",
      "Built and integrated a multi-user collaborative whiteboard with the ability to share images onto the whiteboard and draw on them in color",
      "Added the undo functionality to the whiteboard using a circular buffer to limit memory consumption and for automatic deletion of old data, in addition to the ability to zoom in and out",
      "Integrated a text chat system with translation feature between 104 languages and speech recognition for speech-to-text capabilities in 70 dialects"
    ]
  }
]