import React from 'react';
import {Link} from 'react-router';
import styles from './style.css';
import * as texts from './text.js';

export default class Technical extends React.Component {
  componentDidMount() {
    // Rotate + icon for technical accordion/collapsible
    $('.collapsible-header').click(() => {
      $('.collapsible-header i').css({
        transform: 'rotate(0deg)',
        transition: '250ms all',
        color: '#1394bb'
      });
      
      if($(this).hasClass('active')) {
        $(this).find('i').css({
          transform: 'rotate(0deg)',
          transition: '250ms all',
          color: '#1394bb'
        });
      }
      else {
        $(this).find('i').css({
          transform: 'rotate(45deg)',
          transition: '250ms all',
          color: '#ef6c00'
        });
      }

      $('html, body').animate({
        scrollTop: $('.collapsible').offset().top+'px'
      });
    });
  }

  componentDidUpdate() {
    // If the visitor is viewing the technical section, fill the skills bar
    if(this.props.isViewing) {
      var helper = (elem, amt) => {
        if(amt >= 1)
          return;

        $(elem).css('width', `${Number($(elem).data('max'))*amt}%`);

        setTimeout(helper, 50, elem, amt+0.05);
      };

      $.each($('.determinate'), (index, elem) => {
        setTimeout(helper, 500, elem, 0);
      });
    }
  }

  render() {
    return (
      <div>
        <div className='container'>
          <div className='row'>
            <div className='col s12 m3'>
              <div className={styles.dylect}>
                <a href='https://www.dylect.com' target='_blank'>
                  <img src='https://d3fz6t5y2jh3sz.cloudfront.net/logo-small.png'/>
                </a>
                <h4 className='light'>Dylect</h4>
                <p>Dec. 2015 - Present</p>
                <p>JavaScript/Node.js Developer</p>
              </div>
            </div>
            <div className='col s12 m9'>
              <p>
                <b>Dylect </b>
                <span>is my educational technology startup effort. Dylect (dynamic + lectures) allows educators to expand their services beyond brick walls through video chat built into the browser alongside scheduling functionality and additional features in development.</span>
              </p>
              <ul data-collapsible='accordion' className='collapsible'>
                {
                  texts.dylect.map((subsection, index) => {
                    return (
                      <li key={index}>
                        <div className='collapsible-header'>
                          <i className='material-icons'>add</i>
                          {subsection.title}
                        </div>
                        <div className='collapsible-body'>
                          {
                            subsection.text.map((val, index) => {
                              return (
                                <div key={index} className={styles.dylectDetails}>
                                  <i className='material-icons'>check</i>
                                  <span>{val}</span>
                                </div>
                              )
                            })
                          }
                        </div>
                      </li>
                    )
                  })
                }
              </ul>
            </div>
          </div>
          <hr/>
          <h4 className='light center'>Skills</h4>
          <div className='row'>
            <div className='col s12 m6 offset-m3 l6 offset-l3'>
              <h5 className='light'>Comfortable with</h5>
              <div className='progress white'><div className='determinate blue' data-max='60'></div></div>
              <p>HTML | CSS | JavaScript (JSX, ES6, and Node.js)</p>
              <p>Amazon Web Services | Bootstrap | Express | git | Jade/Pug | jQuery | Linux | Materialize | NoSQL | Socket.io | WebRTC</p>
              <br/>
              <h5 className='light'>Okay with</h5>
              <div className='progress white'><div className='determinate blue' data-max='40'></div></div>
              <p>C | C++ | Java</p>
              <p>axios | Babel | Google (APIs, Apps Script, Cloud Platform, Firebase) | Promises | React.js (with Router) | Regular expressions | Shell script | tracking.js | WebGL (three.js) | Webpack</p>
              <br/>
              <h5 className='light'>I've been exposed to</h5>
              <div className='progress white'><div className='determinate blue' data-max='20'></div></div>
              <p>Assembly | Lisp | MySQL | OCaml | PHP | Python</p>
              <br/>
              <a href='https://github.com/kyoseongku/website' target='_blank' className={`btn-large blue ${styles.repo}`}>GitHub</a>
            </div>
          </div>
          <hr/>
        </div>
        <div id='showcase' className={styles.showcase}>
          <h4 className='light'>Some fiddles</h4>
          <p>(Click each image for more details)</p>
          <div className={`row ${styles.showcaseRow}`}>
            <div className={`col s12 m6 l4 ${styles.showcaseCol}`}>
              <Link to='ar'><img src='https://dysrf6t0c7f2p.cloudfront.net/ar.png' className='responsive-img'/></Link>
            </div>
            <div className={`col s12 m6 l4 ${styles.showcaseCol}`}>
              <Link to='vchat'><img src='https://dysrf6t0c7f2p.cloudfront.net/vchat.jpg' className='responsive-img'/></Link>
            </div>
            <div className={`col s12 m6 l4 ${styles.showcaseCol}`}>
              <Link to='chat'><img src='https://dysrf6t0c7f2p.cloudfront.net/chat2.jpg' className='responsive-img'/></Link>
            </div>
            <div className={`col s12 m6 l4 ${styles.showcaseCol}`}>
              <Link to='map'><img src='https://dysrf6t0c7f2p.cloudfront.net/map.jpg' className='responsive-img'/></Link>
            </div>
            <div className={`col s12 m6 l4 ${styles.showcaseCol}`}>
              <Link to='heli'><img src='https://dysrf6t0c7f2p.cloudfront.net/heli.jpg' className='responsive-img'/></Link>
            </div>
            <div className={`col s12 m6 l4 ${styles.showcaseCol}`}>
              <Link to='sched'><img src='https://dysrf6t0c7f2p.cloudfront.net/sched.jpg' className='responsive-img'/></Link>
            </div>
          </div>
        </div>
      </div>
    );
  }
}