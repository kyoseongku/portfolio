import React from 'react';
import {Link, IndexLink} from 'react-router'
import styles from './style.css';

export default class NotFound extends React.Component {
  componentDidMount() {
    this.handleResize();
    $(window).on('resize', this.handleResize);
  }

  componentWillUnmount() {
    $(window).off('resize');
  }

  handleResize() {
    $(`.${styles.wrapper}`).css('height', $(window).height());
    $(`.${styles.wrapper}`).css('padding-top', ($(window).height()-$('h1').height())/2);
  }

  render() {
    return (
      <div className={`${styles.wrapper} center`}>
        <h1 className='blue-grey-text light'>
          Nothing here. Go away.
        </h1>
        <IndexLink to='/'>MAIN PAGE</IndexLink>
      </div>
    );
  }
}