import React from 'react';
import styles from './style.css';
import * as actions from './actions.js';
import axios from 'axios';

export default class GMaps extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      showForm: false,
      err: false
    };

    this.locate = this.locate.bind(this);
    this.getMap = this.getMap.bind(this);
    this.getPlots = this.getPlots.bind(this);
  }

  componentDidMount() {
    this.handleResize();
    $(window).on('resize', this.handleResize);
  }

  componentWillUnmount() {
    $(window).off('resize');
  }

  componentDidUpdate(prevProps, prevState) {
    if(this.state.err) {
      $('#map').empty();
      $('#map').hide();
    }

    if(this.state.showForm) {
      $('#waypoints, #destination').on('keypress', (event) => {
        if(event.keyCode == 13) {
          event.preventDefault();
          this.getMap();
        }
      });
    }
    else
      $('#waypoints, #destination').off('keypress');
  }

  handleResize() {
    $(`.${styles.projWrapper}`).css('min-height', $(window).height());
  }



  locate() {
    $('#map').empty();

    if(!navigator.geolocation) {
      this.setState({
        showForm: false,
        err: "Your browser doesn't support the geolocation feature. Please try again with another browser."
      });
      return;
    }

    actions.locateSelf()
    .then((data) => {
      let map = actions.drawMap('map', data.coords.lat(), data.coords.lng());
      actions.placeMarker(map, data.coords.lat(), data.coords.lng(), 'Found you!', true);

      this.setState({ showForm: true, err: false });
    }).catch((err) => {
      console.log(err);
      this.setState({ showForm: false, err: err.text });
    });
  }



  getMap() {
    if(!$('#mapOpt1').is(':checked') && !$('#mapOpt2').is(':checked') && !$('#mapOpt3').is(':checked')) {
      alert('You forgot step 1');
      return;
    }

    if($('#mapOpt3').is(':checked') && (!$('#waypoints').val() || $('#waypoints').val() === '')) {
      alert('You forgot step 2');
      return;
    }

    if(!$('#destination').val() || $('#destination').val() === '') {
      alert('You forgot step 3');
      return;
    }

    $('#map').empty();

    var map, directionsDisplay = new google.maps.DirectionsRenderer();

    Promise.all([
      actions.locateSelf(),
      actions.locateDest($('#destination').val())
    ]).then((data) => {
      // Convert from meters to miles
      let distance = 0.000621371*google.maps.geometry.spherical.computeDistanceBetween(data[0].coords, data[1].coords);
      let destMsg = ($('#mapOpt1').is(':checked')) ? `${distance.toFixed(2)} miles away` : 'Destination';

      map = actions.drawMap('map', 0, 0);
      actions.placeMarker(map, data[0].coords.lat(), data[0].coords.lng(), 'You', true);
      actions.placeMarker(map, data[1].coords.lat(), data[1].coords.lng(), destMsg, true);

      let bounds = new google.maps.LatLngBounds();
      bounds.extend(data[0].coords);
      bounds.extend(data[1].coords);
      map.fitBounds(bounds);

      // If straight-line distance mode, stop here
      if($('#mapOpt1').is(':checked'))
        return new Promise((resolve, reject) => {resolve(false)});

      directionsDisplay.setMap(map);

      let request = {
        origin: data[0].coords,
        destination: data[1].coords,
        travelMode: 'DRIVING',
        waypoints: []
      };

      // If waypoints mode
      if($('#mapOpt3').is(':checked')) {
        let waypoints = $('#waypoints').val().split(';');
        for(let i = 0; i < waypoints.length; i++) {
          request.waypoints.push({
            location: waypoints[i],
            stopover: false
          });
        }
      }

      return actions.getRoute(request);
    }).then((result) => {
      if(result)
        directionsDisplay.setDirections(result);

      this.setState({ showForm: false, err: false });
    }).catch((err) => {
      console.log(err);
      this.setState({ showForm: false, err: err.text });
    });
  }



  getPlots() {
    $('#map').empty();

    var map, plotData = [], plotPromises = [];

    axios.get('https://spreadsheets.google.com/feeds/cells/1rslAHywImjLDr0sfzV7G0YWeg8NmaeIxS3aO578IR_o/od6/public/basic?alt=json')
    .then((response) => {
      map = actions.drawMap('map', 0, 0);

      for(let i = 4; i < response.data.feed.entry.length; i += 3) {
        plotData.push({
          name: response.data.feed.entry[i].content.$t,
          addr: response.data.feed.entry[i+1].content.$t,
          type: response.data.feed.entry[i+2].content.$t
        });

        plotPromises.push(actions.locateDest(response.data.feed.entry[i+1].content.$t));
      }

      return Promise.all(plotPromises);
    }).then((results) => {
      let plotMin = {lat: results[0].coords.lat(), lng: results[0].coords.lng()};
      let plotMax = {lat: results[0].coords.lat(), lng: results[0].coords.lng()};

      actions.placeMarker(
        map,
        results[0].coords.lat(), results[0].coords.lng(),
        `<p><b>Name:</b>${plotData[0].name}<br><b>Pizza type:</b> ${plotData[0].type}</p>`,
        false
      );

      for(let i = 1; i < results.length; i++) {
        plotMin.lat = Math.min(plotMin.lat, results[i].coords.lat());
        plotMin.lng = Math.min(plotMin.lng, results[i].coords.lng());
        plotMax.lat = Math.max(plotMax.lat, results[i].coords.lat());
        plotMax.lng = Math.max(plotMax.lng, results[i].coords.lng());

        actions.placeMarker(
          map,
          results[i].coords.lat(), results[i].coords.lng(),
          `<p><b>Name:</b>${plotData[i].name}<br><b>Pizza type:</b> ${plotData[i].type}</p>`,
          false
        );
      }

      let bounds = new google.maps.LatLngBounds();
      bounds.extend(new google.maps.LatLng(plotMin.lat, plotMin.lng));
      bounds.extend(new google.maps.LatLng(plotMax.lat, plotMax.lng));
      map.fitBounds(bounds);

      this.setState({ showForm: false, err: false });
    }).catch((err) => {
      console.log(err);
      this.setState({ showForm: false, err: 'Error retrieving plots' });
    });
  }



  renderForm() {
    return (
      <div>
        <div className="row">
          <div className="col s12 m4 l4">
            <p><b>Step 1:</b> Choose an option</p>
            <p>
              <input id="mapOpt1" name="mapOpt" type="radio" className="with-gap"/>
              <label htmlFor="mapOpt1">Find straight-line distance</label>
            </p>
            <p>
              <input id="mapOpt2" name="mapOpt" type="radio" className="with-gap"/>
              <label htmlFor="mapOpt2">Find path</label>
            </p>
            <p>
              <input id="mapOpt3" name="mapOpt" type="radio" className="with-gap"/>
              <label htmlFor="mapOpt3">Find path with waypoints</label>
            </p>
          </div>
          <div className="col s12 m4 l4">
            <p><b>Step 2:</b> Enter up to 6 waypoints separated by a semi-colon. Valid inputs are the same as step 3. Ex: A ; B ; C</p>
            <div className="input-field col s12">
              <textarea id="waypoints" className="materialize-textarea"></textarea>
              <label htmlFor="waypoints">Enter waypoint(s)</label>
            </div>
          </div>
          <div className="col s12 m4 l4">
            <p><b>Step 3:</b> Enter the destination. Both "1600 Pennsylvania Ave NW, Washington, DC 20500" and "Santa Monica Pier" are valid inputs.</p>
            <div className="input-field col s12">
              <input id="destination" type="text" />
              <label htmlFor="destination">Enter a location</label>
            </div>
          </div>
        </div>
        <div className="center">
          <a className="btn blue" onClick={this.getMap}>Submit</a>
        </div>
      </div>
    );
  }



  render() {
    return (
      <div className={styles.projWrapper}>
        <div className="container">
          <div className="card">
            <div className="card-content">
              <div className={styles.projHeader}>
                <h5 className="light">Playing around with Google Maps API</h5>
                <p>Oct. 2015, expanded Aug. 2016</p>
              </div>
              <div className={styles.projDesc}>
                <p><b>Description:</b></p>
                <p>This fiddle displays the straight-line distance or the path from your current location to any other specified location, with optional waypoints for the latter. It can also retrieve location data from Google Sheets and plot them onto the map.</p>
                <br/>
                <p>I implemented the straight-line distance version as a part of my software engineering class project, which was a "Uber for tutors" web app, and decided to expand on it.</p>
                <p>I came across a gig request for the plots feature, and although it's nothing special I wanted to code it anyway because some not-so-tech-savvy small business owners may find it useful. All they need is an API key from Google, my JavaScript snippet in their WordPress page, and Google Sheets instead of a back-end which pretty much anyone can use.</p>
                <p>Feel free to play with the <a href="https://docs.google.com/spreadsheets/d/1rslAHywImjLDr0sfzV7G0YWeg8NmaeIxS3aO578IR_o" target="_blank">Google Sheets data</a>.</p>
                <br/>
                <p><b>Note:</b></p>
                <p>Please enter valid inputs because there is no input sanitation. I decided against writing additional code since it's redundant to implement Google Maps using Google Maps, unless such integration was necessary/desired for a "native" feel or whatnot.</p>
              </div>
              <div className="row">
                <div className="col s6 m6 l6">
                  <a id="locate" className={`btn blue ${styles.buttons}`} onClick={this.locate}>Locate me</a>
                </div>
                <div className="col s6 m6 l6">
                  <a id="plots" className={`btn blue ${styles.buttons}`} onClick={this.getPlots}>Show plots</a>
                </div>
              </div>
              { this.state.showForm && this.renderForm() }
              { this.state.err && (<h5 className="light">{this.state.err}</h5>) }
              <br/>
              <div id="map" className={styles.map}></div>
            </div>
            <div className="card-action"><a href="/#showcase">Return to homepage</a></div>
          </div>
        </div>
      </div>
    );
  }
}