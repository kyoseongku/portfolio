export function drawMap(mapID, lat, lng) {
  $(`#${mapID}`).show();
  return new google.maps.Map(document.getElementById(mapID), {
    zoom: 13,
    center: new google.maps.LatLng(lat, lng),
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
}



export function placeMarker(map, lat, lng, text, show) {
  var image = {
    url: 'https://dysrf6t0c7f2p.cloudfront.net/map-marker.png',
    size: new google.maps.Size(30, 30),
    origin: new google.maps.Point(0, 0),
    anchor: new google.maps.Point(15, 15)
  };
  
  var info = new google.maps.InfoWindow({
    content: text
  });
  
  var marker = new google.maps.Marker({
    position: new google.maps.LatLng(lat, lng),
    map: map,
    title: text,
    icon: image
  });
  
  marker.addListener('click', function() {
    info.open(map, marker);
  });

  if(show)
    info.open(map, marker);
  
  return marker;
}



export function locateSelf() {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (location) => {
        resolve({
          confidence: 'Your location is accurate within a ' +location.coords.accuracy.toFixed(2) +' meter radius',
          coords: new google.maps.LatLng(location.coords.latitude, location.coords.longitude)
        });
      },
      (err) => {
        reject({ obj: err, text: 'Error: Unable to find your location' });
      }
    );
  });
}



export function locateDest(addr) {
  return new Promise((resolve, reject) => {
    let geocoder = new google.maps.Geocoder();
    geocoder.geocode({address: addr}, function(results, status) {
      if(status == google.maps.GeocoderStatus.OK)
        resolve({coords: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())});
      else
        reject({ obj: status, text: 'Error with geocoder service'});
    });
  });
}



export function getRoute(request) {
  return new Promise((resolve, reject) => {
    let directionsService = new google.maps.DirectionsService();
    directionsService.route(request, (result, status) => {
      if(status == 'OK')
        resolve(result);
      else
        reject({ obj: status, text: 'Error with directions service'});
    });
  });
}