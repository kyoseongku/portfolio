import React from 'react';
import ReactDOM from 'react-dom';
import { Route, Router, IndexRoute, browserHistory } from 'react-router'
import Index from './components/Index/Index';
import AR from './components/AR/AR';
import VChat from './components/VChat/VChat';
import Chat from './components/Chat/Chat';
import GMaps from './components/GMaps/GMaps';
import CPPJava from './components/CPPJava/CPPJava';
import NotFound from './components/NotFound/NotFound';

class Layout extends React.Component {
  render() {
    return (<div>{this.props.children}</div>);
  }
}

// Layout for projects
class Showcase extends React.Component {
  render() {
    let proj = this.props.params.project;
    let component =
      (proj === 'ar')    ? <AR /> :
      (proj === 'vchat') ? <VChat /> :
      (proj === 'chat')  ? <Chat /> :
      (proj === 'map')   ? <GMaps /> :
      (proj === 'heli' || proj === 'sched') ? <CPPJava which={proj} /> :
      <NotFound />;

    return component;
  }
}

const routes = (
  <Route path='/' component={Layout}>
    <IndexRoute component={Index}/>
      <Route path='/:project' component={Showcase}/>
    <Route path='*' component={NotFound}/>
  </Route>
);

ReactDOM.render(
  <Router history={browserHistory} routes={routes} onUpdate={() => window.scrollTo(0, 0)}/>,
  document.getElementById('app')
);